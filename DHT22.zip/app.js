const express = require('express');
const path = require('path');
const net = require('net');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');

const app = express();

const http = require('http').Server(app);
const io = require('socket.io')(http);

const port =3000;
const tcpPort= 5000;

const server = net.createServer((client)=>{
  console.log('Client connection :');
  console.log('   local = %s:%s',client.localAddress,client.localport);
  console.log('   remote = %s:%s',client.remoteAddress,client.remotePort);
  client.setTimeout(500);
  client.setEncoding('utf8');
  client.on('data',(data)=>{
    console.log('Received data from client on port %d: %s', client.remotePort,data.toString());
    console.log('  Bytes received: '+client.bytesRead);
    writeData(client,'Sending: '+data.toString());
    console.log(data);
    console.log('  Bytes sent: '+client.bytesWritten);
  });
  client.on('end',()=>{
    console.log('Client diisconnected');
    server.getConnections((err,count)=>{
      console.log('Remaing Connection: '+ count);
    });
  });
  client.on('error',(err)=>{
    console.log('Socket Error: '+JSON.stringfy(err));
  });
  client.on('timeout',()=>{
    console.log('Socket Timed out');
  });
});

server.listen(tcpPort,()=>{
  console.log('Sever listening: '+JSON.stringify(server.address()));
  server.on('close',()=>{
    console.log('Server Terminated');
  });
  server.on('error',(err)=>{
    console.log('Server Error: '+JSON.stringify(err));
  });
});

function writeData(socket,data) {
  var success = !socket.write(data);
  if(!success){
    (function(socket,data){
      socket.once('drain',()=>{
        writeData(socket,data);
      });
    })(socket,data);
  }
}


// view engine setup
app.set('views', path.join(__dirname, 'views/pages'));
app.set('view engine', 'ejs');

app.use(express.static(path.join(__dirname,'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use('/',require('./api'));

io.on('connection',(socket)=>{
  console.log('a user connected!');
  socket.on('chat message',function (msg) {
    //time
    var now = new Date();
    var hour = now.getHours();
    var min = now.getMinutes();
    //var second = now.getSeconds();
    if(hour>=12){
      hour = '오후 '+(hour-12);
    }
    else{
      hour = '오전 '+hour;
    }
    var time = hour+':'+min;
    console.log(time);
    io.emit('chat message',msg,time);
  });
});

http.listen(port,()=>{
  console.log(`Server listening at port 3000`);
});
module.exports = app;
